/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */
package net.sf.ehcache.constructs.blocking;


import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.constructs.concurrent.Mutex;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;


/**
 * A {@link net.sf.ehcache.Cache} backed cache that creates entries on demand.
 * <p/>
 * Clients of the cache simply call it without needing knowledge of whether
 * the entry exists in the cache, or whether it needs updating before use.
 * <p/>
 *
 * Thread safety depends on the factory being used. The UpdatingCacheEntryFactory should be made
 * thread safe. In addition users of returned values should not modify their contents.
 *
 * @author Greg Luck
 * @version $Id: UpdatingSelfPopulatingCache.java,v 1.4 2006/03/06 07:33:24 gregluck Exp $
 * @see SelfPopulatingCollectionCache
 */
public class UpdatingSelfPopulatingCache extends SelfPopulatingCache {
    private static final Log LOG = LogFactory.getLog(UpdatingSelfPopulatingCache.class.getName());
    private final LockManager lockManager;

    /**
     * Creates a SelfPopulatingCache.
     */
    public UpdatingSelfPopulatingCache(final String name, final UpdatingCacheEntryFactory factory)
        throws CacheException {
        super(name, factory);
        lockManager = new LockManager();
    }


    /**
     * Creates a SelfPopulatingCache and use the given cache manager to create cache objects
     */
    public UpdatingSelfPopulatingCache(final String name, final CacheManager mgr, final CacheEntryFactory factory)
        throws CacheException {
        super(name, mgr, factory);
        lockManager = new LockManager();
    }

    /**
     * Looks up an object.
     * <p/>
     * If null, it creates it. If not null, it updates it. For performance this method should only be
     * used with {@link UpdatingCacheEntryFactory}'s
     * <p/>
     * It is expected that
     * gets, which update as part of the get, might take considerable time. Access to the cache cannot be blocked
     * while that is happening. This method is therefore not synchronized. The {@link LockManager} is used
     * to synchronise individual entries.
     * @param key
     * @return a value
     * @throws net.sf.ehcache.CacheException
     */
    public Serializable get(final Serializable key) throws BlockingCacheException {
        String oldThreadName = Thread.currentThread().getName();
        setThreadName("get", key);

        Serializable value = null;

        try {
            lockManager.acquireLock(key);

            Cache backingCache = getCache();
            Element element = backingCache.get(key);

            if (element == null) {
                value = super.get(key);
            } else {
                value = element.getValue();
                update(key);
            }

            return value;
        } catch (final Throwable throwable) {
            // Could not fetch - Ditch the entry from the cache and rethrow
            setThreadName("put", key);
            put(key, null);

            try {
                throw new BlockingCacheException("Could not fetch object for cache entry \"" + key + "\".", throwable);
            } catch (NoSuchMethodError e) {
                //Running 1.3 or lower
                throw new CacheException("Could not fetch object for cache entry \"" + key + "\".");
            }
        } finally {
            Thread.currentThread().setName(oldThreadName);
            lockManager.releaseLock(key);
        }
    }

    private void update(final Serializable key) {
        try {
            Cache backingCache = getCache();
            final Element element = backingCache.getQuiet(key);

            if (element == null) {
                if (LOG.isTraceEnabled()) {
                    LOG.trace(getName() + ": entry with key " + key + " has been removed - skipping it");
                }
            }

            refreshElement(element, backingCache);
        } catch (final Exception e) {
            // Collect the exception and keep going.
            // Throw the exception once all the entries have been refreshed
            // If the refresh fails, keep the old element. It will simply become staler.
            LOG.warn(getName() + "Could not refresh element " + key, e);
        }
    }

    /**
     * This method should not be used. Because elements are always updated before they are
     * returned, it makes no sense to refresh this cache.
     */
    public void refresh() throws CacheException {
        throw new CacheException("UpdatingSelfPopulatingCache objects should not be refreshed.");
    }

    /**
     * Provides locking at the level of a single cache entry using Doug Lea's concurrency library.
     * <p/>
     * This permits scalability of an order of magnitude higher than simple class instance locking
     * provided by the synchronized method.
     *
     */
    public static class LockManager {
        /**
         * A map of cache entry locks, one per key, if present
         */
        protected final Map locks;

        /**
         * Creates a new LockManager and initialises the locks Map
         */
        public LockManager() {
            locks = new HashMap();
        }

        /**
         * Acquires a lock with the given key.
         * <p/>
         * If the lock does not exist it is created.
         * @param key
         * @throws InterruptedException
         */
        public void acquireLock(Serializable key) throws InterruptedException {
            Mutex lock = checkLockExistsForKey(key);
            lock.acquire();
        }

        /**
         * Releases a lock with the given key
         * <p/>
         * If the lock does not exist it is created.
         * @param key
         */
        public void releaseLock(Serializable key) {
            Mutex lock = checkLockExistsForKey(key);
            lock.release();
        }

        private synchronized Mutex checkLockExistsForKey(final Serializable key) {
            Mutex lock;
            lock = (Mutex) locks.get(key);

            if (lock == null) {
                lock = new Mutex();
                locks.put(key, lock);
            }
            return lock;
        }
    }
}
