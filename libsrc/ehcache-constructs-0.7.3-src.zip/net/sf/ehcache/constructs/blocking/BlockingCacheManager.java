/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */

package net.sf.ehcache.constructs.blocking;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;


/**
 * There can be multiple CacheManagers.
 *
 * @author Greg Luck
 * @author Adam Murdoch
 * @version $Id: BlockingCacheManager.java,v 1.3 2006/03/06 07:33:24 gregluck Exp $
 */
public class BlockingCacheManager {

    private static final Log LOG = LogFactory.getLog(BlockingCacheManager.class.getName());

    /**
     * A custom cache manager, in case the user does not
     * want to use the default cache manager when
     * creating custom caches.
     */
    private static CacheManager manager;

    /**
     * A map of BlockingCaches, keyed by cache name
     */
    protected final Map caches;


    /**
     * Empty Constructor
     */
    public BlockingCacheManager() {
        caches = new HashMap();
    }

    /**
     * Constructor that assigns the cache manager to use when
     * creating caches.
     */
    public BlockingCacheManager(CacheManager mgr) {
        manager = mgr;
        caches = new HashMap();
    }

    /**
     * Creates a cache.
     */
    public BlockingCache getCache(final String name) throws CacheException {
        // Lookup the cache
        BlockingCache blockingCache = (BlockingCache) caches.get(name);
        if (blockingCache != null) {
            return blockingCache;
        }

        // Create the cache
        synchronized (this) {
            if (manager == null) {
                blockingCache = new BlockingCache(name);
            } else {
                blockingCache = new BlockingCache(name, manager);
            }

            caches.put(name, blockingCache);
            return blockingCache;
        }
    }

    /**
     * Drops the contents of all caches.
     */
    public void clearAll() throws CacheException {
        final List cacheList = getCaches();
        if (LOG.isDebugEnabled()) {
            LOG.debug("Removing all blocking caches");
        }
        for (int i = 0; i < cacheList.size(); i++) {
            final BlockingCache cache = (BlockingCache) cacheList.get(i);
            cache.clear();
        }
    }

    /**
     * Drops the contents of a named cache.
     */
    public void clear(final String name) throws CacheException {
        final BlockingCache blockingCache = (BlockingCache) getCache(name);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Clearing " + name);
        }
        blockingCache.clear();
    }

    /**
     * Returns the EHCache Cache Manager used in creating Blocking Caches.
     *
     * @return The cache manager
     */
    protected CacheManager getCacheManager() {
        return manager;
    }

    /**
     * Sets the EHCache Cache Manager used in creating blocking caches.
     *
     * @param mgr The new manager to use
     */
    protected void setCacheManager(CacheManager mgr) {
        manager = mgr;
    }

    /**
     * Builds the set of caches.
     * Returns a copy so that the monitor can be released.
     */
    private synchronized List getCaches() {
        final ArrayList blockingCaches = new ArrayList();
        blockingCaches.addAll(this.caches.values());
        return blockingCaches;
    }

}

