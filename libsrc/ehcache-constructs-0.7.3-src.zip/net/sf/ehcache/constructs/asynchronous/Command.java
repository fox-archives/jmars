/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */

package net.sf.ehcache.constructs.asynchronous;

import java.io.Serializable;


/**
 * An asynchronous encapsulated command. Callers do not need to know what the command does.
 * <p/>
 * Commands must be serializable, so that they be persisted to disk by ehcache.
 * <p/>
 * The command can also be fault tolerant. It is made fault tolerant when {@link #getThrowablesToRetryOn()}  is non null.
 * Any {@link Throwable}s thrown that are <<code>instanceof</code> a <code>Throwable</code> in the array are expected
 * and will result in reexecution up to the maximum number of attempts, after the delay between repeats.
 * allowing a delay each time.
 *
 * @author <a href="mailto:gluck@thoughtworks.com">Greg Luck</a>
 * @version $Id: Command.java,v 1.2 2005/07/13 18:52:41 gregluck Exp $
 */
public interface Command extends Serializable {

    /**
     * Executes the command. The command is successful if it does not throw an exception.
     * @throws Throwable A command could do anything and could throw any {@link Exception} or {@link Error}
     * @see #getThrowablesToRetryOn() to set {@link Throwable}s that should are expected
     */
    void execute() throws Throwable;

    /**
     * The AsynchronousCommandExecutor may also be fault tolerant. This method returns a list of {@link Throwable}
     * classes such that if one if thrown during an execute attempt the command will simply retry after an interval
     * until it uses up all of its retry attempts. If a {@link Throwable} does occurs which is not in this list,
     * an {@link AsynchronousCommandException} will be thrown and the command will be removed.
     * <p>
     * @return a list of {@link Class}s. It only makes sense for the list to contain Classes which are subclasses
     * of Throwable
     */
    Class[] getThrowablesToRetryOn();

    /**
     * @return  the number of times the dispatcher should try to send the message. A non-zero value implies fault tolerance
     * and only makes sense if {@link #getThrowablesToRetryOn()} is non-null.
     */
    int getNumberOfAttempts();

    /**
     * @return the delay between attempts, in seconds. A non-zero value implies fault tolerance
     * and only makes sense if {@link #getThrowablesToRetryOn()} is non-null.
     */
    int getDelayBetweenAttemptsInSeconds();


}
